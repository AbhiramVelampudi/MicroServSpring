# Quiz Microservices Project

## 📌 Overview
This project demonstrates **inter-service communication** using **WebClient** in a microservices architecture. It consists of three microservices:

1. **Quiz Service** → Calls Questions and Certificates services using WebClient.
2. **Questions Service** → Stores and retrieves quiz questions in MongoDB.
3. **Certificates Service** → Issues certificates for completed quizzes.

## 🚀 How to Run

### 1️⃣ Start MongoDB
Run MongoDB using Docker:
```sh
docker-compose up -d
```

OR start MongoDB manually if installed locally.

### 2️⃣ Start Each Microservice
Navigate to each microservice directory and run:
```sh
mvn spring-boot:run
```

### 3️⃣ Insert Sample Data
Use MongoDB Compass or Mongo Shell to manually insert sample data.

### 4️⃣ Test Endpoints
Use **Postman** or **Curl** to test API endpoints.

## 🔗 API Endpoints
| Service | Endpoint | Description |
|---------|---------|------------|
| Questions Service | `GET /questions/{id}` | Fetch question |
| Quiz Service | `GET /quizzes/question/{id}` | Fetch question via WebClient |
| Certificates Service | `POST /certificates` | Issue certificate |

## 📂 Project Structure
```
quiz-microservices/
│── quiz-service/
│── questions-service/
│── certificates-service/
│── docker-compose.yml  (MongoDB Setup)
│── README.md
```

## 📌 Technologies Used
- **Spring Boot (WebFlux)**
- **MongoDB**
- **WebClient for Inter-Service Communication**
- **Resilience4j for Circuit Breaker**
